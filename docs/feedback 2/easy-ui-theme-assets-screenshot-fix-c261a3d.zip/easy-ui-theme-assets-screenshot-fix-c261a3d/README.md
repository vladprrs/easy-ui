# easy-ui theme-assets screenshot fix

Пакет для передачи разработчикам easy-ui.

## Состав

- `TASK.md` — постановка, root cause, security constraints и acceptance criteria.
- `patches/0001-fix-allow-theme-assets-in-screenshot-capture.patch` — готовый git patch.
- `verification/summary.txt` — проверенные команды и результаты.
- `SHA256SUMS` — контрольные суммы файлов пакета.

## Git metadata

```text
Repository: https://github.com/vladprrs/easy-ui
Base:       73a01b8e66adf6ad8df3594c8789581608300a82
Commit:     c261a3d
Branch:     fix/theme-assets-screenshot-allowlist
```

## Как применить

Из корня checkout easy-ui:

```bash
git checkout -b fix/theme-assets-screenshot-allowlist origin/main
git am /path/to/patches/0001-fix-allow-theme-assets-in-screenshot-capture.patch
npm run server:typecheck
bun test server/screenshot.test.ts
npm run server:test
npm run verify
```

Если актуальный `main` ушёл вперёд и `git am` конфликтует:

```bash
git am --abort
```

После этого перенести те же два логических изменения вручную, сохранив требования из `TASK.md`: pinned theme version для prototype и exact asset IDs без wildcard.

## Что архив не содержит

- credentials;
- production config;
- private Figma/Arcadia data;
- production database;
- font binaries;
- полный source repository.
